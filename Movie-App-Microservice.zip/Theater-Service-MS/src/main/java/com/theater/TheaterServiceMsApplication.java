package com.theater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheaterServiceMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheaterServiceMsApplication.class, args);
	}

}
