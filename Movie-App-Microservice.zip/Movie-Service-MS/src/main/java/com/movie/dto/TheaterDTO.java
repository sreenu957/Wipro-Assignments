package com.movie.dto;

import lombok.Data;

@Data
public class TheaterDTO {
    private Long id;
    private String name;
    private String location;
}
