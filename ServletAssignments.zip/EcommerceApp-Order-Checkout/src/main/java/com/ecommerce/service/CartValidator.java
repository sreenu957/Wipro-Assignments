package com.ecommerce.service;

public interface CartValidator {
	boolean validateCart(String cartId);

}
