package com.ecommerce.service;

public interface OrderService {
	
	String checkout(String cartId);

}
